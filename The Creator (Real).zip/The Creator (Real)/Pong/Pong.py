import pygame as g
from sys import exit

# inception
g.init()

# declaration
clock = g.time.Clock()
text = g.font.Font("Font\Pixeltype.ttf", 35)
score = 0

# creating graphics
window = g.display.set_mode((850, 520))
window.fill("#000000")
split = g.Surface((4, 520))
split.fill("#A9A9A9")
playerScore = text.render("Score: "+ str(score), True, "White")

# looping so that window doesn't close
while True:
    for event in g.event.get():
        if event.type == g.QUIT:
            g.quit()
            exit()
            
    window.blit(split, (423, 0))
    window.blit(playerScore, (25, 25))
    
    # updating display at 60fps
    g.display.update()
    clock.tick(60)
