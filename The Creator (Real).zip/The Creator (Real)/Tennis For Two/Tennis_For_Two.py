import pygame as g
from sys import exit
import random as r

g.init()
xLen = 640
yLen = 480
xCoord = xLen / 2
yCoord = yLen / 2
xBall = xCoord
yBall = yCoord
velocity = 1

window = g.display.set_mode((xLen, yLen))
g.display.set_caption("The Test")

clock = g.time.Clock()
text = g.font.Font("Font/Pixeltype.ttf", 50) # font type, font size

score = 0
acc = 1
lineStart = (0, 400)
lineEnd = (640, 400)

white = ("#FFFFFF")
black = ("#000000")
Lgrey = ("#B2BEB5")

window.fill(black)
#bat = g.Rect((21, 3))
textSurface = text.render("Level 1", False, "White") # text, anti-aliasing (smoothing edges of text), colour 

def goUp(limit):
     while limit != 50:
         xBall -= velocity
         velocity += 1
         limit += 1

game = True
while True: # loop to stop window from closing
    for event in g.event.get():
        if event.type == g.QUIT:
            g.quit()
            exit()
            
    acc = 1                        
    maxHeight = 10
    
    window.fill(black)
    ball = g.Rect(xBall, yBall, 7, 7)
    
    g.draw.line(window, (Lgrey), (lineStart), (lineEnd), 5) 
    g.draw.line(window, (Lgrey), (320, 350), (320, 400), 5)
    g.draw.rect(window, (white), ball) 

    xBall = ball.x
    yBall = ball.y

    if yBall >= 400 or yBall <= 0:
        goUp(1)
    else:
        yBall += 3

    g.display.flip()
    
    clock.tick(60)
    
g.quit()
