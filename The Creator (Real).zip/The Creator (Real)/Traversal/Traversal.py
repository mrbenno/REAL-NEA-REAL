from pydoc import plainpager
from turtle import forward
import pygame 
from sys import exit

pygame.init()

window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
pygame.display.set_caption("Thomas was Alone")
winX = window.get_width() 
winY = window.get_height()

frame = pygame.time.Clock()

def rect(pos, scale, colour):
    sqr = pygame.Rect(pos[0], pos[1], scale[0], scale[1])            
    pygame.draw.rect(window, (colour), sqr)  
    
class Player:
    #constructer
    def __init__(self, pos, scale, colour):
        self.pos = pos
        self.scale = scale
        self.colour = colour
    
    #function which animates player
    def animate(self, x, y):
        self.pos[0] += x
        self.pos[1] += y
            #friendly reminder #1: self means actual object being edited, anything not 'self.' normal var

#friendly reminder #2: don't need to declare variable type in construct, will do so here auto
player1 = Player([175, 450], [25, 25], '#0A9B9A')
   
playerX = 175
playerY = 450
speed = 0 
inAir = False
jump = 0

rectTop = 150

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
            
    window.fill("#000000")

    keys = pygame.key.get_pressed()
        
    rect([0, (winY -150)], [(winX), 150], "#2E2D2D")

    rect(player1.pos, player1.scale, player1.colour)
    
    if player1pos[1] 
        
    
    if player1.pos[1] <= ((window.get_height() - 150) - (player1.pos[1])): #ewhfui
        speed += 1 #aebhfuaihui
    else:
        speed -= 1

    if keys[pygame.K_SPACE]: #sbhgshvr
        player1.animate(0,speed)
        speed = -10 #ngigrnefienn
    
    if keys[pygame.K_a]:
        player1.animate(-5, 0)
        
    if keys[pygame.K_d]:
        player1.animate(5, 0)
        


    
    pygame.display.flip()
    
    frame.tick(60)
